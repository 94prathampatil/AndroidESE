package com.example.question5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        TextView textView = findViewById(R.id.textView);
        ImageView imageView = findViewById(R.id.imageView);

        String lang = getIntent().getStringExtra("lang");
        textView.setText("Language: "+lang);

        switch (lang) {
            case "Java":
                imageView.setImageResource(R.drawable.java);
                break;
            case "C++":
                imageView.setImageResource(R.drawable.cplusplus);
                break;
            case "Python":
                imageView.setImageResource(R.drawable.python);
                break;
            case "JavaScript":
                imageView.setImageResource(R.drawable.javascript);
                break;
        }
    }
}