package com.example.question9;

import androidx.appcompat.app.AppCompatActivity;

import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
    }

    public void change(View view) {
        RadioButton radioButton = (RadioButton) view;
        if(radioButton.getId() == R.id.rb1) {
            imageView.setImageResource(R.drawable.male);
        } else if(radioButton.getId() == R.id.rb2) {
            imageView.setImageResource(R.drawable.female);
        }
    }
}