package com.example.question3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText editText;
    Spinner spinner;
    TextView result;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.editText);
        spinner = findViewById(R.id.spinner);
        result = findViewById(R.id.result);

        String choice[] = {"Hex", "Binary"};
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choice);
        spinner.setAdapter(arrayAdapter);

    }

    public void convert(View view) {
        if(!editText.getText().toString().isEmpty()) {
            int num = Integer.parseInt(editText.getText().toString());
            if(spinner.getSelectedItem().toString().equals("Hex")) {
                result.setText(Integer.toHexString(num));
            } else if (spinner.getSelectedItem().toString().equals("Binary")) {
                result.setText(Integer.toBinaryString(num));
            }
        }
    }
}